package com.scuba.AccessModifiers;

public class DefaultAccessModifier {
	 public static void main(String args[]){  
		 DefaultAccessModifier1 obj = new DefaultAccessModifier1();//Compile Time Error  
		   obj.msg();//Compile Time Error  
		  }  
}
