package com.scuba.AccessModifiers;

import com.scuba.AccessModifiers1.PublicAccessModifier1;

public class PublicAccessModifier {
	public static void main(String args[]){  
		PublicAccessModifier1 obj = new PublicAccessModifier1();  
		   obj.msg();  
	}
}
