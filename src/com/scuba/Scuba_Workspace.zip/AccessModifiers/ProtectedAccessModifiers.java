package com.scuba.AccessModifiers;

import com.scuba.AccessModifiers1.ProtectedAccessModifiers1;

class ProtectedAccessModifiers {
	public static void main(String args[]) {
		ProtectedAccessModifiers1 obj = new ProtectedAccessModifiers1();  
		   obj.msg();
	}
}
