package com.scuba.AccessModifiers1;

public class ProtectedAccessModifiers1 {
	public void msg() {
		System.out.println("Hello");
		}
}
