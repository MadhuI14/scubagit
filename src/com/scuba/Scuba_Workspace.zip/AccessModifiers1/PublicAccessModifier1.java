package com.scuba.AccessModifiers1;

public class PublicAccessModifier1 {
	public void msg() {
		System.out.println("Hello");
		} 
}
