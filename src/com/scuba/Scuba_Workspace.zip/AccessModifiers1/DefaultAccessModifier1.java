package com.scuba.AccessModifiers1;

public class DefaultAccessModifier1 {
	void msg() {
		System.out.println("Hello");
		}
}
